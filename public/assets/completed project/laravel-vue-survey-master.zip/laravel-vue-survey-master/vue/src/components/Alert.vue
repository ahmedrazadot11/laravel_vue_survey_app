<template>
  <div
    class="flex items-center justify-between py-3 px-5 bg-red-500 text-white rounded"
  >
    <slot></slot>

  </div>
</template>

<script setup>

</script>

<style></style>
